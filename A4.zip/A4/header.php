<!DOCTYPE html>
<html>
    <?php require_once("connect.inc.php");?>
    <head>
            <link rel="stylesheet" href="style.css" title="text/css">
            <script src="main.js"></script>
            <title>
                Assignment-3
            </title>
    </head>
    <body>
        <div id="topbg">
            <div id="top-image" class="float-left">
                <img src="images/sc.png" alt="SoundCloud" title="SoundCloud" height="40px" width="auto">
            </div>
<!--            <div class="clear"></div>-->
            <div class="float-left text-style">
                <ul class="topnav-style">
                    <li>
                        <a href="#">Home</a>
                    </li>
                    <li>
                        <a href="#">Stream</a>
                    </li>
                    <li>
                        <a href="#">Collection</a>
                    </li>
                </ul>
            </div>
            <div id="searchbar">
                <form method="post" action="#">
                        <input placeholder="Search for artist,bands,tracks,podcasts" name="search" />
                </form>
            </div>
            <!--<div class="clear"></div>-->
            <div class="float-right top-padding">
                <div id="signin-btn">
                    <ul class="signin-btn">
                        <li>
                            <a href="login.php">Sign in</a>
                        </li>
                        <li>
                            <a href="signup.php">Create account</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    