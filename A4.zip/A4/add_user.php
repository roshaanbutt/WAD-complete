<?php
    require_once("connect.inc.php");
    $User_name= $_POST["name"];
    $User_email= $_POST["email"];
    $User_pwd= $_POST["pwd"];
    $sql = "INSERT INTO users (name,email,password) VALUES ('". $User_name . "','". $User_email ."','". $User_pwd."')";
    if (mysqli_query($mysql_connect, $sql)) {
          echo "New record created successfully";
//          sleep(1);
//          header('Location:index.php');
    } else {
          echo "Error: " . $sql . "<br>" . mysqli_error($mysql_connect);
    }
?>

