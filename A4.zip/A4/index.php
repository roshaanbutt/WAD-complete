<?php 
    require('header.php'); 
?>
<div class="clear"></div>
    <div class="form-align">
        <p>Login</p>
        <form method="post" action="#">
            <input class="form-input" type="email" placeholder="Your email address or profile URL *" name="email" /><br>
            <input class="form-input" type="password" placeholder="Your password" name="pwd" /><br>
            <input class="form-input-button" type="submit" name="submit123" value="Continue" />
        </form>
        <?php
            if(isset($_POST['pwd'])&&isset($_POST['email'])){
                $_pass=$_POST['pwd'];
                $e_mail=$_POST['email'];
                if(empty($_pass)||empty($e_mail)){ 
                echo 'Fill all fields!!!';
            }
            else {
                require ('loginuser.php');
            }
        } ?>
        
</div>
<?php 
    require('footer.php'); 
?>