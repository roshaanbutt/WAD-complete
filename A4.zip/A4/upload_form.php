<?php
    require 'connect.inc.php';
    require 'logout_header.php';
?>

<div class="form-align">
        <form method="post" action="#" enctype="multipart/form-data">
            <input class="form-input" type="name" placeholder="Enter Album Name" name="name" /><br>
            Select the type Song:
            <select name="album_type">
                <option value="rock">Rock</option>
                <option value="pop">Pop</option>
                <option value="jazz">Jazz</option>
                <option value="goth">Goth</option>
                 <option value="electric">Electric</option>
            </select></br>
            Select audio  file to upload:
            <input type="file" name="audio"/></br>
            Select image to upload:
            <input type="file" name="image"/>
            <input class="form-input-button" type="submit" name="submit123" value="Upload" />
        </form>
</div>
<?php
    require 'upload-form-php.php';
?>