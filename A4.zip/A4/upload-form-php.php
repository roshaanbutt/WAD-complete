<?php
    if(count($_POST)>0){
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false){
        $image = $_FILES['image']['tmp_name'];
        $audio_file = $_POST['album_type'];
        $audio = $_File['audio']['tmp_name'];
        $album_name=$_POST['name'];
        $album_type=$_POST['album_type'];
        $imgContent = addslashes(file_get_contents($image));
        $insert = "INSERT into core (album_name,album_type,image,audio_file) VALUES ('".$album_name."','".$album_type."','".$imgContent."','".$audio."')";
        if(mysqli_query($mysql_connect, $insert)){
            echo "File uploaded successfully.";
        }else{
            echo "File upload failed, please try again.";
        } 
    }else{
        echo "Please enter name and select an image file to upload.";
    }
}
?>