function formvalidatefunc()                                    
{ 
    var fname = document.forms["RegForm"]["name"];              
    var email = document.forms["RegForm"]["email"];    
    var pass = document.forms["RegForm"]["pwd"];
    var passc = document.forms["RegForm"]["pwdc"];

    if (fname.value == "")                                  
    { 
        window.alert("Please enter your name ."); 
        name.focus(); 
        return false; 
    }
    if (pass.value == "")                                   
    { 
        window.alert("Please enter password ."); 
        pass.focus(); 
        return false; 
    } 
     if (passc.value != pass.value)                                   
    { 
        window.alert("Password do not match ."); 
        pass.focus(); 
        return false; 
    } 
    if (passc.value == "")                                   
    { 
        window.alert("Please enter confirm password ."); 
        passc.focus(); 
        return false; 
    } 
	if (email.value.indexOf("@", 0) < 0)                 
    { 
        window.alert("Please enter a valid e-mail address."); 
        email.focus(); 
        return false; 
    } 
	if (!validateEmail(email.value))                                  
    { 
        window.alert("Please enter valid email."); 
        email.focus(); 
        return false; 
    }
    
   
   
    if (what.selectedIndex < 1)                  
    { 
        alert("Please enter your course."); 
        what.focus(); 
        return false; 
    } 
   
    return true; 
}
function validateEmail(email) 
{
    var re = /\S+@\S+/;
    return re.test(email);
}
	
