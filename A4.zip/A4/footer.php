
<div class="footer">
    <p>Legal - Privacy - Cookies - Imprint - Charts - Popular searches</p>
    <div><span>Language:</span>English (US)</div>
</div>
</body>
</html>