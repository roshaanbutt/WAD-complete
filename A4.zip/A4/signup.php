<?php 
    require('header.php'); 
?>
<div class="clear"></div>
    <div class="form-align">
        <p>Signup</p>
        <form method="post" name="RegForm" action="" onsubmit="return formvalidatefunc()">
            <input class="form-input" type="text" placeholder="Your name" name="name" /><br>
            <input class="form-input" type="email" placeholder="Your email" name="email" /><br>
            <input class="form-input" type="password" placeholder="Your password" name="pwd" /><br>
            <input class="form-input" type="password" placeholder="Confirm password" name="pwdc" /><br>
            <input class="form-input-button" type="submit" name="submit123" value="Continue" />
        </form>
        <?php 
            if(count($_POST)>0) {
                $text=$_POST['pwd'];
                $pattern="/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/";
                if(preg_match($pattern,$text)){
                    require('add_user.php');
                }else{
                    echo"Password must be of 6 in size contain numbers ,letters !!";
            }
            } 
        ?>
</div>
<div class="clear"></div>

<?php 
    require('footer.php'); 
?>