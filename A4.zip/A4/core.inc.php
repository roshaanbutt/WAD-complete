<?php
    ob_start();
    session_start();
    $current_file=$_SERVER['SCRIPT_NAME'];
    $http_referer=$_SERVER['HTTP_REFERER'];
    function login()
    {
        if(isset($_SESSION['user_email'])&&!empty($_SESSION['user_email'])){
            return true;
        }
        else{
            return false;
        }
    }
?>