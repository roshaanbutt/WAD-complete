CREATE TABLE `core` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `album_name` varchar(30) NOT NULL,
`album_type` varchar(30) NOT NULL,
 `image` longblob NOT NULL,
`audio_file` longblob NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;