<?php
    require 'connect.inc.php';
    require 'core.inc.php';
    if(login())
    { 
        require 'logout_header.php';
        require 'view_img.php';
//<!--        <i>You are Logged in!</i><br>
//        <button style="
//            padding: 7px;
//            width: 150px;
//            background-color: #FF5500;
//            border: 0px;
//            font-family: Arial, Helvetica, sans-serif;
//            font-size: 20px;
//            margin-top: 8px;
//            border-radius: 5px;">
//            <a style="text-decoration: none;color: white;" id="logout-btn" href='logout.php'>Logout</a></button>-->
        
   }
    else {
        require 'index.php';
    }
    
?>