$sql="SELECT  sound FROM english WHERE eWord LIKE '%" . $name .  "%' OR kWord LIKE '%" . $name ."%'";

while($row=mysql_fetch_array($result)){

   $sound=$row['sound'];

   echo '<audio controls>';
      echo    '<source src="data:audio/mp3;base64,'.$row['sound'].'">';
   echo '</audio>';