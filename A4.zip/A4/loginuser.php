<?php
if(count($_POST)>0) {
    require_once("connect.inc.php");
    if(isset($_POST["email"])){
        $_email=$_POST["email"];
        $_pwd=$_POST["pwd"];
    $sql = "SELECT * FROM users WHERE email='".$_email."' AND password='".$_pwd."'";
    $check=mysqli_query($mysql_connect,$sql);
    if(mysqli_num_rows($check)==1)
    {
        $_SESSION['user_email']=$_email;
        header('Location:login.php');
    }
    else {
        echo "Your Email or Password is Incorrect!";
    }
    }
    }
?>