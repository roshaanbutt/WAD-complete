<?php  
    require_once("connect.inc.php");
    $query = "SELECT * FROM core ORDER BY id DESC";  
    $result = mysqli_query($mysql_connect, $query);  
    while($row = mysqli_fetch_array($result))  
    {  
         echo '  
              <tr>  
                   <td>  
                        <img src="data:images/jpeg;base64,'.base64_encode($row['image'] ).'" height="200" width="200" " />  
                   </td>  
              </tr>  
         ';  
    }  
?>  