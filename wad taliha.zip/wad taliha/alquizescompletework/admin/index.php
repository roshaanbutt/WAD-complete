<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width initial-scale=1">
	<title>Admin Panel</title>
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head> <!--^(\+92|0)-?\d{3}-?\d{7}   ^(((^\0)+)\d+)   (^\0{1,})(\d{2,})      ((^0+)\d+)-->
	<h1> Admin panel</h1>
	<div class="container-fluid" style="height:400px;background-color:skyblue">
		<div class="row">
			<div class="col-6 col-sm-3 col-md-9 col-lg-1" style="height:100px;background-color:black">
		
			</div>
			<div class="col-6 col-sm-3 col-md-1 col-lg-6" style="height:100px;background-color:red">
		
			</div>
			<div class="col-6 col-sm-3 col-md-1 col-lg-3" style="height:100px;background-color:pink">
		
			</div>
			<div class="col-6 col-sm-3 col-md-1 col-lg-2" style="height:100px;background-color:yellow">
		
			</div>
		</div>
		
	</div>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>