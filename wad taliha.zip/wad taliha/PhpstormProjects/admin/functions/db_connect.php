<?php
$con = mysqli_connect("localhost","root","","store_db");
if(!$con)
    die("connection failed");