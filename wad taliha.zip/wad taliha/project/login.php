<!DOCTYPE html>
<?php
session_start();
include ('includes/db_connect.php');
$error_msg = '';
?>
<?php
if(isset($_GET['login'])){
    $email = $_GET['user_email'];
    $pass = $_GET['user_pass'];
    $sel_user = "select * from register where u_email='$email' AND u_password='$pass'";
    $run_user = mysqli_query($con, $sel_user);
    $check_user = mysqli_num_rows($run_user);
    if($check_user==0){
        $error_msg = 'Password or Email is wrong, try again';
    }
    else{
        $_SESSION['user_email'] = $email;
        if(!empty($_GET['remember'])) {
            setcookie('user_email', $email, time() + ( 10 * 365 * 24 * 60 * 60));
            setcookie('user_pass', $pass, time() + (10 * 365 * 24 * 60 * 60));
        } else {
            setcookie('user_email','' );
            setcookie('user_pass', '');
        }
        header('location:details.php?logged_in=You have successfully logged in!');
    }
}
?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Log-In</title> 
	<meta name="description" content="job searching tutorials">
	<meta name="keywords" content="job searching">
	<meta name="author" content="KT">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="cssk/menuvalid.css">
	<link rel="stylesheet" href="cssk/style.css">
</head> 
<body style="padding-top: 0px;">
<div class="bdy">
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-12" style="height:150px;width:100%">
			<a href="index.php"><img id="logo" src="images/logo.gif"></a>
			<img id="banner" src="images/banner.gif">
		</div>
	<!---	<div class="col-sm-12" style="height:auto;width:100%">
			<ul class="list-inline" style="margin-bottom: 0rem;" >
			  <li class="list-inline-item"><a href="index.php"> <b> Home</b> </a></li>
			  <li class="list-inline-item"><a href="about.php"> <b>About</b> </a></li>
			  <li class="list-inline-item"><a href="contact.php"> <b>Contact</b> </a></li>
			  <li class="list-inline-item"><a href="login.php"> <b>Login</b> </a></li>
			  <li class="list-inline-item"><a href="register.php"> <b>Register</b> </a></li>
			  <li class="list-inline-item"><a href="fg.php"> <b>Forget-Password<b> </a></li>
			  
			</ul>
		    </div>   -->
	</div>
</div>	

<div class="container-fluid">	
			<img id="contentimg" src="images/paper.jpg" style="width:100%; min-height: 800px;">
	<div class="text-block">
		<div class="row">
			<div class="offset-md-2 col-md-8">
				<form action="" method="GET" enctype="multipart/form-data">
					<br><br>
					<div><?php echo $error_msg;?></div>
					<div class="form-group row">
						<h2 class="offset-lg-3 offset-md-2 offset-1 " align="center" 
						style="color: mediumvioletred; font-size: 50px;  font-family: cursive; maargin:auto"> Log-In </h2>
					</div>
					
					<div class="form-group row">
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="email">Email</label>
						
						   <div class="sm-3 col-12 col-sm-6">
							<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
							class="form-control" type="text" id="email" name="user_email"
                            value="<?php echo @$_COOKIE['user_email']?>"placeholder="Email" required
							pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
							</div>
					</div>
				   
					<div class="form-group row">
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px"
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="password">Password</label>
						
							<div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="password" id="password" name="user_pass"
								value="<?php echo @$_COOKIE['user_pass']?>"placeholder="Password" required>
								<p style="font-family: cursive; color: rebeccapurple; font-size: 10px">Password contains atleast 7 characters<p>
							</div>
					</div>
					
					<div class="form-check">
						<div class="offset-sm-3 col-12 col-sm-6">
					
                            <input type="checkbox" class="form-check-input" id="remember" name="remember">
                            <label class="form-check-label" for="remember"style="font-family: cursive; color: rebeccapurple; font-size: 20px">
							Remember me</label>
                        </div>
					</div>
					
					<div class="form-group row">
						<div class="offset-sm-3 col-12 col-sm-6">
							<input class="btn btn-block btn-success btn-lg" style="font-family: cursive; color: white; font-size: 20px"
							type="submit" id="login" name="login"
							value="Log-In">
						</div>
					</div>
					
					
				</form>
			</div>
		</div>	
	</div> 
</div>	
</div>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>