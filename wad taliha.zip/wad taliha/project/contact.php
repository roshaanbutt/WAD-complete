<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <title>ContactUs</title>
    <meta name="description" content="job searching tutorials">
	<meta name="keywords" content="job searching">
	<meta name="author" content="KT">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="css/menuvalid.css">
	<link rel="stylesheet" href="cssk/style.css">
</head> 
<body style="padding-top: 0px;">
<div class="bdy">
<div class="container-fluid">
    <div class="row">   
		<div class="col-sm-12" style="height:150px;width:100%">
			<a href="index.php"><img id="logo" src="images/logo.gif"></a>
			<img id="banner" src="images/banner.gif">
		</div>
		<div class="col-sm-12" style="height:auto;width:100%">
			<ul class="list-inline" style="margin-bottom: 0rem;">
			  <li class="list-inline-item"><a href="index.php"> <b> Home</b> </a></li>
			  <li class="list-inline-item"><a href="about.php"> <b>About</b> </a></li>
			  <li class="list-inline-item"><a href="contact.php"> <b>Contact</b> </a></li>
			  <li class="list-inline-item"><a href="login.php"> <b>Login</b> </a></li>
			  <li class="list-inline-item"><a href="register.php"> <b>Register</b> </a></li>
			  <li class="list-inline-item"><a href="fg.php"> <b>Forget-Password<b> </a></li>
			  
			</ul>
		</div>
	</div>
</div>			
			
		
<div class="container-fluid">	
   <img id="contentimg" src="images/paper.jpg" style="width:100%; min-height: 800px;">
	<div class="text-block">
		<div class="row">
			<div class="offset-md-2 col-md-8">
				<form action="" method="post" enctype="multipart/form-data">
					<br><br>
					<div class="form-group row">
						<h2 class="offset-lg-3 offset-md-2 offset-1 " align="center" 
						style="color: mediumvioletred; font-size: 50px;  font-family: cursive; maargin:auto"> Contact Us </h2>
					</div>
					
					<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="name">Name</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="text" id="name" name="name" placeholder="Name" required>
								</div>
					</div>
						
					<div class="form-group row">
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="Phone#">Phone#</label>
						
						   <div class="sm-3 col-12 col-sm-6">
							<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
							class="form-control" type="text" id="phone#" name="email" placeholder="Email" required pattern="^\d{3}-\d{3}-\d{4}$">
							</div>
					</div>	
					
					<div class="form-group row">
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="email">Email</label>
						
						   <div class="sm-3 col-12 col-sm-6">
							<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
							class="form-control" type="text" id="email" name="email" placeholder="Email" required
							pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$">
							</div>
					</div>
				   
					<div class="form-group row">
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px"
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="password">Password</label>
						
							<div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="password" id="password" name="password" placeholder="Password" required pattern=".{7,}">
								<p style="font-family: cursive; color: rebeccapurple; font-size: 10px">Password contains atleast 7 characters<p>
							</div>
					</div>
					
					<div class="form-group row">
	              			
						<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
						class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="msg">Message</label>
						
						   <div class="sm-3 col-12 col-sm-6">
						   
                                  <textarea name="Message" class="form-control" rows="4"   placeholder="Message">

                                  </textarea><br>							   
							</div>
					</div>
					
					<div class="form-group row">
						<div class="offset-sm-3 col-12 col-sm-6">
							<input class="btn btn-block btn-success btn-lg" style="font-family: cursive; color: white; font-size: 20px"
							type="submit" id="Submit" name="Submit"
							value="Submit">
						</div>
					</div>
				</form>
			</div>
		</div>	
	</div>
     <br><br>
	
					<div id="add">			 
					    <div class="col-md-4">
							
								<div class="card-body">
									<h4 class="card-title" style="color: grey;">Address</h4>
									<p class="card-text" style="color: gray;">jobee@jobee.pk</p>
								</div>
							
						</div>	
					</div>
				    <br>
				    <div id="add1">
                        <div class="col-md-4">					
                                <div class="card-body">								
									<h4 class="card-title" style="color: grey;">Phone</h4>
									<p class="card-text" style="color: gray;">123111121</p>
                                </div> 
                           
				        </div>
					</div>	
</div>
        
								<br><br><br><br>
								<div id="add2">
								   <div class="col-12">
								     <h7>You can also see our location on GOOGLE map</h7>
								   </div>
								</div>
								
								<div id="add3">
								    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d2483.140189993619!2d-0.0773503!3d51.510644!3m2!1i1024!2i768!4f13.1!4m3!3e6!4m0!4m0!5e0!3m2!1sen!2s!4v1523967032255"
								    width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>		  
		                        </div>
</div>	
	
    <script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>