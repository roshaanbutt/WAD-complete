<?php 
	$con = mysqli_connect("localhost",
	"root","","jobe");
	if(!$con)
		die("connection failed");

?>