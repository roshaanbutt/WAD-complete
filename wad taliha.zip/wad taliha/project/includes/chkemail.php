<?php
require "db_connect.php";
$email=$_GET['e'];
$chkmail="select * from register where u_email='$email'";
$run_mail=mysqli_query($con,$chkmail);
$count=mysqli_num_rows($run_mail);
if($count>0){
    echo"email already registered";
}