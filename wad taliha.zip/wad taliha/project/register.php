<!DOCTYPE html>
<?php
session_start();
require "functions/functions.php";
?>
<html>
<head>
	<meta charset="UTF-8">
    <title>Register</title>
	<meta name="description" content="job searching tutorials">
	<meta name="keywords" content="job searching">
	<meta name="author" content="KT">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/menuvalid.css">
	<link rel="stylesheet" href="cssk/style.css">

</head> 

<body style="padding-top: 0px;">
<div class="bdy">
<div class="container-fluid" >
    <div class="row">
		<div class="col-sm-12" style="height:150px;width:100%">
			<a href="index.php"><img id="logo" src="images/logo.gif"></a>
			<img id="banner" src="images/banner.gif">
		</div>
		<div class="col-sm-12" style="height:auto;width:100%">
            <div class="Welcome">
			      <span >
						<?php
                        if(!isset($_SESSION['user_email']))
                            echo "Welcome guest!";
                        else
                            echo "Welcome ".$_SESSION['user_email'];
                        ?>
                        <?php
                        if(!isset($_SESSION['user_email'])){
                            echo "<a style='color: orange;' href='login.php'>Login</a>";
                        }
                        else{
                            echo "<a style='color: orange;' href='logout.php'>Logout</a>";
                        }
                        ?>


                    </span>
            </div>
			<ul class="list-inline" style="margin-bottom: 0rem;">
			  <li class="list-inline-item"><a href="index.php"> <b> Home</b> </a></li>
			  <li class="list-inline-item"><a href="about.php"> <b>About</b> </a></li>
			  <li class="list-inline-item"><a href="contact.php"> <b>Contact</b> </a></li>
			  <li class="list-inline-item"><a href="login.php"> <b>Login</b> </a></li>
			  <li class="list-inline-item"><a href="register.php"> <b>Register</b> </a></li>
			  <li class="list-inline-item"><a href="fg.php"> <b>Forget-Password<b> </a></li>
			  
			</ul>
		</div>
	</div>	
</div>
<div class="container-fluid" >
	<img id="contentimg" src="images/paper.jpg" style="width:100%;min-height: 800px; ">
		<div class="text-block">		
			<div class="row">
				<div class="offset-md-2 col-md-8">
					<form action="" method="GET" enctype="multipart/form-data">
						<br><br>
						<div class="form-group row">
							<h2 class="offset-lg-3 offset-md-2 offset-1 " align="center" 
							style="color: olivedrab; font-size: 50px;  font-family: cursive; maargin:auto">
							Registration </h2>
						</div>
						
						<div class="form-group row">
							<h3 class="offset-lg-3 offset-md-2 offset-1 " align="center" 
							style="color: mediumvioletred; font-size: 30px;  font-family: cursive; maargin:auto">
							Insert your data here </h3>
						</div>
						
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="fname">FirstName</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="text" id="fname" name="fname"
                                       placeholder="Firstname" required pattern="[a-zA-Z\-'\s]+">
								</div>
						</div>
						
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="lname">LastName</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="text" id="lname" name="lname" placeholder="LastName"
                                       required pattern="[a-zA-Z\-'\s]+">
								</div>
						</div>
						
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="gender">Gender</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="text" id="gender" name="gender" placeholder="Gender" required>
								</div>
						</div>
						
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="bday">DOB</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" type="date" id="bd" name="bday" required>
								</div>
						</div>
						
						
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px" 
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="email">Email</label>
							
							   <div class="sm-3 col-12 col-sm-6">
								<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
								class="form-control" onkeyup="chkemail(this.value)" type="text" name="email" size="30" placeholder="Email" required
                                       pattern="^([a-zA-Z])[\w\.-_]+@(ucp\.edu\.pk|gmail\.com)$"><br>
                                   <span id="emai"></span>
								</div>
						</div>
					   
						<div class="form-group row">
							<label style="font-family: cursive; color: rebeccapurple; font-size: 20px"
							class="col-form-label col-sm-4 col-lg-3 d-none d-sm-block" for="password">Password</label>
							
								<div class="sm-3 col-12 col-sm-6">
									<input style="font-family: cursive; color: rebeccapurple; font-size: 20px"
									class="form-control" type="password" id="password" name="pass" placeholder="Password" required pattern=".{7,}">
									<p style="font-family: cursive; color: rebeccapurple; font-size: 10px">Password contains atleast 7 characters<p>
								</div>
						</div>
						
						<div class="form-group row">
							<div class="offset-sm-3 col-12 col-sm-6">
								<input class="btn btn-block btn-success btn-lg" style="font-family: cursive; color: white; font-size: 20px"
								type="submit" id="register" name="register"
								value="register">
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
</div>	
	</div>
    <script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>
	 <script>
         function chkemail(email) {
             console.log(email);
             if(email==''){
                 document.getElementById('emai').innerText='';
             }
             else{
                 var http=new XMLHttpRequest();
                 http.onreadystatechange=function () {
                     if(http.readyState==4&&http.status==200){
                         document.getElementById('emai').innerText=http.responseText;
                         
                     }
                 }
                 http.open('get','includes/chkemail.php?e='+email);
                 http.send();
             }
         }
    </script>
</body>
</html>

<?php
if(isset($_GET["register"]))
{
	
	$u_firstname = $_GET['fname'];
	$u_lastname= $_GET['lname'];
	$u_gender = $_GET['gender'];
	$u_dob = $_GET['bday'];
	$u_email= $_GET['email'];
	$u_password= $_GET['pass'];
	
	
	$insert_u = "insert into register(u_firstname ,u_lastname,u_gender,u_dob,u_email, u_password)
		values ('$u_firstname ','$u_lastname','$u_gender','$u_dob','$u_email','$u_password')";
		
	$run_insert = mysqli_query($con,$insert_u);
    /*if($run_insert)
    {
        header('location: '.$_SERVER['PHP_SELF']);
    }*/

}
?>