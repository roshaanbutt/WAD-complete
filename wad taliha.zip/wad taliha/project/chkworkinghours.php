<!DOCTYPE html>
<?php
session_start();
require "functions/functions.php";
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Jobee.pk</title>
    <!--<link rel="stylesheet" type="text/css" href="css/main.css">-->
    <meta name="description" content="job searching tutorials">
    <meta name="keywords" content="job searching">
    <meta name="author" content="KT">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/menuvalid.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
<!--<div class="container-fluid" >-->
<div class="row">
    <div class="col-sm-12" style="height:150px;width:100%">
        <a href="index.php"><img id="logo" src="images/logo.gif"></a>
        <img id="banner" src="images/banner.gif">
    </div>
</div>
<!--</div>-->
<div class="row">
    <div class="col-12">
        <div class="Welcome">
			      <span >
						<?php
                        if(!isset($_SESSION['user_email']))
                            echo "Welcome guest!";
                        else
                            echo "Welcome ".$_SESSION['user_email'];
                        ?>
                        <?php
                        if(!isset($_SESSION['user_email'])){
                            echo "<a style='color: orange;' href='login.php'>Login</a>";
                        }
                        else{
                            echo "<a style='color: orange;' href='logout.php'>Logout</a>";
                        }
                        ?>


                    </span>
        </div>
        <ul class="list-inline" >
            <li class="list-inline-item"><a href="index.php"> <b> Home</b> </a></li>
            <li class="list-inline-item"><a href="about.php"> <b>About</b> </a></li>
            <li class="list-inline-item"><a href="contact.php"> <b>Contact</b> </a></li>
            <li class="list-inline-item"><a href="login.php"> <b>Login</b> </a></li>
            <li class="list-inline-item"><a href="register.php"> <b>Register</b> </a></li>
            <li class="list-inline-item"><a href="fg.php"> <b>Forget-Password<b> </a></li>
        </ul>
    </div>
</div>
<div class="row">
    <div class="col-12">
            <?php
            $jobe_id=$_GET['calculate'];
            $get_pro = "select * from job where j_id='$jobe_id'";
            $run_pro = mysqli_query($con,$get_pro);
            $count_pro = mysqli_num_rows($run_pro);
            $row_pro = mysqli_fetch_array($run_pro);
            $j_id = $row_pro['j_id'];
            $j_cat = $row_pro['j_cat'];

            $job_title = $row_pro['job_title'];
            $job_salary = $row_pro['job_salary'];
            $whrperday = $row_pro['working hours per day'];
            $monthly=$whrperday*20;
            echo "
							<div class='single_product'>
								<h3>$job_title<h3>

								 <p>Job Salary: Rs $job_salary/-  <p>
								 <p>Job Working Hours Per Day:$whrperday  <p>
								  <p>Monthly Hours: $monthly  <p>
							</div>
					";
            ?>
</div>
</div>
<footer class="page-footer font-small blue-grey lighten-5" style="background-color: #009688;">

    <div style="background-color: #21d192;">
        <div class="container" >

            <!-- Grid row-->
            <div class="row py-4 d-flex align-items-center">

                <!-- Grid column -->
                <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
                    <h6 class="mb-0">Get connected with us on social networks!</h6>
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-6 col-lg-7 text-center text-md-right">

                    <!-- Facebook -->
                    <a class="fb-ic">
                        <i class="fa fa-facebook white-text mr-4"> </i>
                    </a>
                    <!-- Twitter -->
                    <a class="tw-ic">
                        <i class="fa fa-twitter white-text mr-4"> </i>
                    </a>
                    <!-- Google +-->
                    <a class="gplus-ic">
                        <i class="fa fa-google-plus white-text mr-4"> </i>
                    </a>
                    <!--Linkedin -->
                    <a class="li-ic">
                        <i class="fa fa-linkedin white-text mr-4"> </i>
                    </a>
                    <!--Instagram-->
                    <a class="ins-ic">
                        <i class="fa fa-instagram white-text"> </i>
                    </a>

                </div>
                <!-- Grid column -->

            </div>
            <!-- Grid row-->

        </div>
    </div>

    <!-- Footer Links -->
    <div class="container text-center text-md-left mt-5 " >

        <!-- Grid row -->
        <div class="row mt-3 dark-grey-text">

            <!-- Grid column -->
            <div class="col-md-3 col-lg-4 col-xl-3 mb-4">

                <!-- Content -->
                <h6 class="text-uppercase font-weight-bold">Company name</h6>
                <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
                <p>Jobee.pk a website to search jobs.</p>

            </div>
            <!-- Grid column -->

            <!-- Grid column -->


            <!-- Grid column -->

            <!-- Grid column -->
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

                <!-- Links -->
                <h6 class="text-uppercase font-weight-bold">Contact</h6>
                <hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
                <p>
                    <i class="fa fa-home mr-3"></i> New York, NY 10012, US</p>
                <p>
                    <i class="fa fa-envelope mr-3"></i>info@example.com</p>
                <p>
                    <i class="fa fa-phone mr-3"></i> + 01 234 567 88</p>
                <p>
                    <i class="fa fa-print mr-3"></i> + 01 234 567 89</p>

            </div>
            <!-- Grid column -->

        </div>
        <!-- Grid row -->

    </div>
    <!-- Footer Links -->

    <!-- Copyright -->
    <div class="footer-copyright text-center text-black-50 py-3">© 2018 Copyright:
        <a class="dark-grey-text" href="index.php"> Jobee.PK</a>
    </div>
    <!-- Copyright -->

</footer>

<!-- Footer -->


<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>