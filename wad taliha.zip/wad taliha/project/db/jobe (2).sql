-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 13, 2018 at 07:17 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jobe`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `c_id` int(10) NOT NULL,
  `c_title` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`c_id`, `c_title`) VALUES
(1, 'Internship Jobs '),
(2, 'Part Time Jobs '),
(3, 'Full Time Jobs'),
(4, ' Contract Jobs ');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE `job` (
  `j_id` int(10) NOT NULL,
  `j_cat` int(10) NOT NULL,
  `job_title` varchar(20) NOT NULL,
  `job_salary` int(30) NOT NULL,
  `job_desc` varchar(30) NOT NULL,
  `job_keywords` varchar(30) NOT NULL,
  `working hours per day` int(10) NOT NULL,
  `companyname` varchar(20) NOT NULL,
  `experience` varchar(20) NOT NULL,
  `lastdate` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`j_id`, `j_cat`, `job_title`, `job_salary`, `job_desc`, `job_keywords`, `working hours per day`, `companyname`, `experience`, `lastdate`) VALUES
(1, 1, 'graphic designer', 5000, 'learn to develop new things', 'graphic', 7, 'arfatower', '2 Years', '20/9/2018'),
(2, 4, 'software engineer', 10000, 'contract base job', 'contract', 8, 'netsol', '3 Year', '22/9/2018'),
(3, 2, 'seo', 4000, 'optimize seraching', 'seo', 5, 'K&T', 'no', '25/9/2018'),
(4, 1, 'logo design', 10000, 'desiging of logos', 'logo', 6, 'ucp', 'no', '30/9/2018');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `u_id` int(10) NOT NULL,
  `u_firstname` varchar(30) NOT NULL,
  `u_lastname` varchar(30) NOT NULL,
  `u_gender` varchar(30) NOT NULL,
  `u_dob` date NOT NULL,
  `u_email` varchar(30) NOT NULL,
  `u_password` varchar(30) NOT NULL,
  `u_cnfrmpass` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`u_id`, `u_firstname`, `u_lastname`, `u_gender`, `u_dob`, `u_email`, `u_password`, `u_cnfrmpass`) VALUES
(1, 'taliha ', 'arif', 'female', '1111-01-01', 'talihaarif@ucp.edu.pk', '1234', '1234'),
(13, 'fatima ', 'arif', 'female', '2005-12-14', 'talihaarif13@gmail.com', 'afbtjsa', ''),
(14, 'fatima ', 'arif', 'female', '2005-12-14', 'talihaarif13@gmail.com', 'afbtjsa', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `job`
--
ALTER TABLE `job`
  ADD PRIMARY KEY (`j_id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `c_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `job`
--
ALTER TABLE `job`
  MODIFY `j_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `u_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
