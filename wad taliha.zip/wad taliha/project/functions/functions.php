<?php
	require "./includes/db_connect.php";
	function getCats(){
		global $con;
		$get_cats = "select * from categories";
		$run_cats = mysqli_query($con,$get_cats);
		while($row = mysqli_fetch_array($run_cats)){
			$c_id = $row['c_id'];
			$c_title = $row['c_title'];
			
			echo "<li><a href='newpage.php?cat=$c_id'>$c_title</a></li>";
		}
	}
	
	//getting the user IP address
function getIp() {
    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    return $ip;
}

function getjobs($flag = ''){
    global $con;
    $get_pro = "";
    if(!isset($_GET['cat'])  && !isset($_GET['search'])) {
        if($flag == 'newpage.php')
            $get_pro = "select * from job";
        else
            $get_pro = "select * from job order by RAND() limit 0,2";
    } else if(isset($_GET['cat'])){
        $j_cat = $_GET['cat'];
        $get_pro = "select * from job where j_cat='$j_cat'";
    }  else if(isset($_GET['search'])){
        $search_query = $_GET['user_query'];
        $get_pro = "select * from job where job_keywords like '%$search_query%'";
    }
    $run_pro = mysqli_query($con,$get_pro);
    $count_pro = mysqli_num_rows($run_pro);
    if($count_pro==0){
        echo "<h2> No Jobs found in selected criteria </h2>";
    }
    while($row_pro = mysqli_fetch_array($run_pro)){
		
        $j_id = $row_pro['j_id'];
		
        $j_cat = $row_pro['j_cat'];
       
        $job_title = $row_pro['job_title'];
        $job_salary = $row_pro['job_salary'];
		$whrperday = $row_pro['working hours per day'];
        echo "
                <div class='single_product'>
                 <h3>$job_title</h3>
				 <p> <b>Job Salary: Rs $job_salary/-  </b> </p> 
				 <a href='chkyearsalary.php?calculate=$j_id'>Check Year Salary</a><br>
                 <p> <b>Job Working Hour: $whrperday </b></p> 
				 <a href='chkworkinghours.php?calculate=$j_id'><button >
				 Check Monthly Hours</button></a>
				  <a href='details.php?detail=$j_id'><button style='margin-left:10px;'>
				          Details</button></a><br><br>  
                </div>
        ";
		
	}	
}
?>


