﻿<!DOCTYPE html>
<?php
session_start();
require "./includes/db_connect.php";
if(!isset($_SESSION['user_email'])){
    header('location: login.php?not_admin=Please login!');
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <title>Jobee.pk</title>
    <!--<link rel="stylesheet" type="text/css" href="css/main.css">-->
    <meta name="description" content="job searching tutorials">
    <meta name="keywords" content="job searching">
    <meta name="author" content="KT">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/menuvalid.css">
    <link rel="stylesheet" href="css/style.css">

</head>
<body>
<div class="row">
    <div class="col-sm-12">
        <h1>Job Detail</h1>
        <table class="table table-striped">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Job title</th>
                <th scope="col">Job salary</th>
                <th scope="col">Job desc</th>
                <th scope="col">Job keywords</th>
                <th scope="col">companyname</th>
                <th scope="col">experience</th>
                <th scope="col">lastdate</th>
            </tr>
            </thead>
            <tbody>
            <?php
            if(isset($_GET['detail'])) {
                $jobe_id=$_GET['detail'];

                $get_brands = "select * from job where j_id='$jobe_id'";
                $run_brands = mysqli_query($con, $get_brands);
                $i=0;
                while ($row_brands= mysqli_fetch_array($run_brands)){
                    $brand_id = $row_brands['j_id'];
                    $j_cat = $row_brands['j_cat'];
                    $job_title = $row_brands['job_title'];
                    $job_salary= $row_brands['job_salary'];
                    $job_desc = $row_brands['job_desc'];
                    $job_keywords = $row_brands['job_keywords'];
                    $workinghoursperday = $row_brands['working hours per day'];
                    $companyname = $row_brands['companyname'];
                    $experience = $row_brands['experience'];
                    $lastdate = $row_brands['lastdate'];

                    ?>
                    <tr>
                        <th scope="row"><?php echo ++$i; ?></th>
                        <td><?php echo $job_title; ?></td>
                        <td><?php echo $job_salary;?></td>
                        <td><?php echo $job_desc;?></td>
                        <td><?php echo $job_keywords;?></td>
                        <td><?php echo $companyname;?></td>
                        <td><?php echo $experience;?></td>
                        <td><?php echo $lastdate;?></td>
                    </tr>
                    <?php
                }
            }

            ?>
            </tbody>
        </table>
        <a class="btn btn-primary" href="#" role="button" style="margin-left: 40%;">
            <i class="fa fa-user-md"></i><input class="btn btn-primary" type="submit" value="Apply for Job"></a>
    </div>
</div>
</body>
