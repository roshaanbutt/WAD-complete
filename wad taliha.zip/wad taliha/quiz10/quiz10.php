<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width initial-scale=1">
    <title>quiz10</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
</head>
<body>
<div class="container offset-md-3" style="height:auto;margin-top:10%;border-radius:2px;border-color: black">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12 col-12">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="form-group row">
                    <h2 class="offset-lg-3 offset-md-2 offset-1 "> create Your google account </h2>
                </div>
                <div class="form-group row">
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                        <input class="form-control" type="text" id="fname" name="first_name" placeholder="First name">
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                        <input class="form-control" type="text" id="lname" name="last_name" placeholder="last name">
                    </div>
                </div>




                <div class="form-group row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
                        <input class="form-control" type="text" id="uname" name="user_name" placeholder="user name">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                        <input class="form-control" type="text" id="password" name="password" placeholder="password">
                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6">
                        <input class="form-control" type="text" id="confrm password" name="confrm password" placeholder="confirm password">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="offset-sm-3 col-12 col-sm-6">
                        <input class="btn btn-block btn-primary btn-lg" type="submit" id="next" name="next"
                               value="next">
                    </div>
                </div>
            </form>
        </div>
        <div class="col-md-6 d-none d-sm-none d-md-block d-lg-block d-xl-block">
            <img src="image/account.JPG">
        </div>
    </div>
</div>

<script src="assets/js/jquery-3.3.1.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>