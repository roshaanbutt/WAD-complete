<?php
$connection = mysqli_connect('localhost','root','','ucp');
if(!$connection)
    die("'ucp' database not connected.");